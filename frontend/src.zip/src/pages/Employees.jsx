export default function Employees() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold">Employees</h1>
      <p className="text-gray-500 mt-2">
        Employees module coming next.
      </p>
    </div>
  );
}

