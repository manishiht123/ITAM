import React, { useState } from "react";
import "./AddAsset.css";
import { useNavigate } from "react-router-dom";

export default function AddAsset() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    assetId: "",
    assetType: "",
    assetStatus: "Available",
    department: "",
    location: "",
    assetOwner: "",

    makeModel: "",
    serialNumber: "",
    cpu: "",
    ram: "",
    storage: "",
    os: "",
    additionalItems: "",

    confidentiality: "",
    integrity: "",
    availability: "",
    sensitivity: "",

    purchaseDate: "",
    warrantyExpiry: "",
    price: "",
    invoiceNumber: "",
    vendorName: "",
    insurance: "No",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  return (
    <div className="add-asset-page">
      {/* HEADER */}
      <div className="page-header">
        <h1>Add Asset</h1>
        <p>Create a new asset in inventory</p>
      </div>

      <form className="asset-form">

        {/* ================= ASSET INFORMATION ================= */}
        <section className="form-section">
          <h3>Asset Information</h3>

          <div className="form-grid">
            <input name="assetId" placeholder="Asset ID" onChange={handleChange} />
            
            <select name="assetType" onChange={handleChange}>
              <option value="">Asset Type</option>
              <option>Laptop</option>
              <option>Desktop</option>
              <option>Server</option>
              <option>Mobile</option>
            </select>

            <select name="assetStatus" disabled>
              <option>Available</option>
            </select>

            <select name="department" onChange={handleChange}>
              <option value="">Department</option>
              <option>IT</option>
              <option>Finance</option>
              <option>HR</option>
              <option>Sales</option>
              <option>Operations</option>
            </select>

            <input name="location" placeholder="User Location" onChange={handleChange} />
            <input name="assetOwner" placeholder="Asset Owner (Entity)" onChange={handleChange} />
          </div>
        </section>

        {/* ================= HARDWARE SPECIFICATION ================= */}
        <section className="form-section">
          <h3>Hardware Specification</h3>

          <div className="form-grid">
            <input name="makeModel" placeholder="Make / Model" onChange={handleChange} />
            <input name="serialNumber" placeholder="Serial Number" onChange={handleChange} />
            <input name="cpu" placeholder="CPU" onChange={handleChange} />
            <input name="ram" placeholder="RAM" onChange={handleChange} />
            <input name="storage" placeholder="Storage" onChange={handleChange} />
            <input name="os" placeholder="Operating System" onChange={handleChange} />
            <input name="additionalItems" placeholder="Additional Items" onChange={handleChange} />
          </div>
        </section>


        {/* ================= PROCUREMENT & FINANCIAL ================= */}
        <section className="form-section">
          <h3>Procurement & Financial</h3>

          <div className="form-grid">
            <input type="date" name="purchaseDate" onChange={handleChange} />
            <input type="date" name="warrantyExpiry" onChange={handleChange} />
            <input name="price" placeholder="Price" onChange={handleChange} />
            <input name="invoiceNumber" placeholder="Invoice Number" onChange={handleChange} />
            <input name="vendorName" placeholder="Vendor Name" onChange={handleChange} />
         </div>
       </section>	  


	  {/* ================= INSURANCE ================= */}
       <section className="form-section">
          <h3>Insurance</h3>
	  <div className="form-grid">
            <select name="insurance" onChange={handleChange}>
              <option>No</option>
              <option>Yes</option>
            </select>
	  </div>
        </section>

        {/* ================= ACTIONS ================= */}
        <div className="form-actions">
          <button type="button" className="btn-secondary" onClick={() => navigate("/assets")}>
            Cancel
          </button>

          <button type="submit" className="btn-primary">
            Save Asset
          </button>

          <button type="button" className="btn-outline">
            Save & Allocate
          </button>
        </div>

      </form>
    </div>
  );
}

